import { inject, Service, signal } from '@angular/core';
import { LoginForm } from '../interfaces/login-form';
import { environment } from '../../../environments/environment.development';
import { HttpClient } from '@angular/common/http';
import { catchError, map, tap, of } from 'rxjs';
import { TokonsService } from './tokons.service';
import { Router } from '@angular/router';
import { User } from '../models/User';
import { IToken } from '../interfaces/iToken';

const API_URL = environment.servidor + '/api/auth';

@Service()

export class AuthService {

  private http = inject(HttpClient);
  private readonly srvTokens = inject(TokonsService);
  private readonly router = inject(Router);
  public userActualS = signal(new User);

  public login(datos : LoginForm) {
    return this.http.patch<IToken>(API_URL, datos)
      .pipe(
        tap((tokens) => {
          //console.log(tokens);
          this.doLogin(tokens);
        }),
        map(() => true),
        catchError((error) => {
         // console.log(error);
         return of (error.status);
        })
      )
  }
  public logout() {
    if (this.isLoggedIn()) {
      this.http.patch(`${API_URL}/logout/${this.userActual.cedula}`,{})
        .subscribe();      
      this.doLogOut();    
    }

  }
  doLogin(tokens  : any) {
    //guardar los tokens
    this.srvTokens.setTokens(tokens);
    //actualizar datos globales para usuario y rol
    this.userActualS.set(this.userActual);
  }
  doLogOut() {
    //Eliminar los tokens
    if (this.srvTokens.token) {
      this.srvTokens.eliminarTokens();
    }
    //limpiar datos globales para usuario y rol
    this.userActualS.set(this.userActual);

    //navegar a la página de login
    this.router.navigate(['/login']);
  }
  public isLoggedIn() : boolean {
    return !!this.srvTokens.token && !this.srvTokens.jwtTokenExp();
  }
  public get userActual() : User {
    if(!this.srvTokens.token) {
      return new User();
    } else {
      const tokenD = this.srvTokens.decodeToken();
      return new User({cedula: tokenD.sub, nombre: tokenD.nom, rol: tokenD.rol })
    }
  }
  public refreshSession() : any {
    if (this.isLoggedIn() && this.srvTokens.tokenTimeToExp() <= 20) {
      return this.http.patch<IToken>(`${API_URL}/refresh/${this.userActual.cedula}`, 
        {tkRef: this.srvTokens.refreshToken})
        .pipe(
          tap((tokens) => {
            //console.log(tokens);
            this.doLogin(tokens);
          }),
          map(() => true),
          catchError((error) => {
          // console.log(error);
          return of (error.status);
          })
        )      
    }
  }
}
