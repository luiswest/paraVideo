import { Routes } from '@angular/router';

export const routes: Routes = [
    { path: '', loadComponent: () => import('./components/home/home')
        .then(m => m.Home)},

    { path: 'home', loadComponent: () => import('./components/home/home')
        .then(m => m.Home) },

    { path: 'cliente', loadComponent: () => import('./components/cliente/cliente')
        .then(m => m.Cliente) },
        
    { path: 'mecanico', loadComponent: () => import ('./components/mecanico/mecanico')
        .then(m => m.Mecanico)
    },
    { path: 'login', loadComponent: () => import ('./components/login/login')
        .then(m => m.Login)
    }
];
