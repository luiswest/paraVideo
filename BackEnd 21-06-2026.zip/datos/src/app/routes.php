<?php
namespace App\controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Firebase\JWT\ExpiredException;
use JimTools\JwtAuth\Exceptions\AuthorizationException;
use JimTools\JwtAuth\Exceptions\TokenExpiredException;

use Slim\Routing\RouteCollectorProxy;

$app->get('/hello/{name}', function (Request $request, Response $response, array $args) {
    $name = $args['name'];
    $response->getBody()->write("Hello, $name");
    return $response;
});

$app->group('/api', function(RouteCollectorProxy $api) {
    $api->group('/cliente', function(RouteCollectorProxy $endpoint) {
        $endpoint->get('[/{id}]', Cliente::class . ':read');
        $endpoint->post('', Cliente::class . ':create');
        $endpoint->put('/{id}', Cliente::class . ':update');
        $endpoint->delete('/{id}', Cliente::class . ':delete');
        $endpoint->get('/filter/{pag}/{lim}', Cliente::class . ':filter');
    });
    $api->group('/mecanico', function(RouteCollectorProxy $endpoint) {
        $endpoint->get('[/{id}]', Mecanico::class . ':read');
        $endpoint->post('', Mecanico::class . ':create');
        $endpoint->put('/{id}', Mecanico::class . ':update');
        $endpoint->delete('/{id}', Mecanico::class . ':delete');
        $endpoint->get('/filter/{pag}/{lim}', Mecanico::class . ':filter');
    });

    $api->group('/auth', function(RouteCollectorProxy $endpoint) {
        $endpoint->patch('', Auth::class . ':login');
        $endpoint->patch('/{id}', Auth::class . ':logout');
    });
    $api->group('/token', function(RouteCollectorProxy $endpoint) {
        $endpoint->patch('/modificar', Token::class . ':modificarToken');
        $endpoint->patch('/verificar/{id}', Token::class . ':verificarToken');
    });

    $api->group('/usuario', function(RouteCollectorProxy $endpoint) {
        $endpoint->patch('/passw/{id}', Usuario::class . ':changePassw');
        $endpoint->patch('/passw/reset/{id}', Usuario::class . ':resetPassw');
        $endpoint->patch('/rol/{id}', Usuario::class . ':changeRol');
        $endpoint->get('/buscar/{id}', Usuario::class . ':buscar');
    });    
});